package com.yash.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IOController {

	@GetMapping("/")
	public String readFile(ModelMap modelMap) {
		modelMap.put("name", "Shital");
		modelMap.put("message", "Welcome to Web page....");
		return "actionpage";
	}
}
