package com.yash.controller;

import java.io.File;   
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.yash.model.TestConfiguration;
import com.yash.service.FileUploadService;

@RestController
@RequestMapping("/test")
public class TestController {
	String sourcefilepath = "E:/Shital/EQUIP_TestConfiguration.xlsx";
	String destfilepath = "E:/Shital/EQUIP_TestConfiguration1.xlsx";
	
	@Autowired
	FileUploadService fileUploadService;
	
	@GetMapping("/welcome")
	public String home(){
		return "Welcome...to Spring Boot Rest Application";
	}
	@PostMapping(value="/readFileContents")
	public ResponseEntity<List<TestConfiguration>> readTest(){
		
		List<TestConfiguration> testConfigurations = null;
		try {
			testConfigurations = fileUploadService.readExcelFileUsingPOI(Files.newInputStream(Paths.get(sourcefilepath)),sourcefilepath);

			return new ResponseEntity<List<TestConfiguration>>(testConfigurations, HttpStatus.OK);
		} catch (IOException e) {
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}			
	}	
	
	@PostMapping(value="/save")
	public ResponseEntity<TestConfiguration> save(TestConfiguration testConfiguration){
		System.out.println("------"+testConfiguration);
		try {
			Files.deleteIfExists(Paths.get(destfilepath));
			Files.createFile(Paths.get(destfilepath));
			String message = fileUploadService.saveFileContents(new File(destfilepath), testConfiguration,destfilepath);
			testConfiguration.setMessage(message);
			return new ResponseEntity<TestConfiguration>(testConfiguration, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			testConfiguration.setMessage("Failed to save...Try again.");
			return new ResponseEntity<TestConfiguration>(testConfiguration, HttpStatus.BAD_REQUEST);
		}
	}	
}
