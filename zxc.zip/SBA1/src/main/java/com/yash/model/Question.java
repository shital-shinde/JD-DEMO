package com.yash.model;

import java.util.List;

public class Question {
	int id;
	String question;
	int option_1;
	int option_2;
	int option_3;
	int option_4;
	int answer;
	String as;
	String status;
	List<Question> questions;
	
	public Question(){}
	
	public Question(int id, String question, int option_1, int option_2, int option_3, int option_4, int answer) {
		this.id = id;
		this.question = question;
		this.option_1 = option_1;
		this.option_2 = option_2;
		this.option_3 = option_3;
		this.option_4 = option_4;
		this.answer = answer;
	}
	public Question(String question, int option_1, int option_2, int option_3, int option_4, int answer) {
		this.question = question;
		this.option_1 = option_1;
		this.option_2 = option_2;
		this.option_3 = option_3;
		this.option_4 = option_4;
		this.answer = answer;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getOption_1() {
		return option_1;
	}
	public void setOption_1(int option_1) {
		this.option_1 = option_1;
	}
	public int getOption_2() {
		return option_2;
	}
	public void setOption_2(int option_2) {
		this.option_2 = option_2;
	}
	public int getOption_3() {
		return option_3;
	}
	public void setOption_3(int option_3) {
		this.option_3 = option_3;
	}
	public int getOption_4() {
		return option_4;
	}
	public void setOption_4(int option_4) {
		this.option_4 = option_4;
	}
	public int getAnswer() {
		return answer;
	}
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	public String getAs() {
		return as;
	}
	public void setAs(String as) {
		this.as = as;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Question [id="+id+", question=" + question + ", option_1=" + option_1 + ", option_2=" + option_2 + ", option_3="
				+ option_3 + ", option_4=" + option_4 + ", answer=" + answer + ", status="+status+"]";
	}		
}
