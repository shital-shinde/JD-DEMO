package com.yash.model;

import java.util.List;

public class TestConfiguration {
	String id;	
	String execute;
	String buildNo;
	String fileLocation;
	String userId;
	String password;
	String databaseName;
	String profileName;
	String emailId;
	String dbServerName;
	String dbUserId;
	String dbPassword;
	String dbName;
	String d;
	String status;
	String message;
	List<TestConfiguration> testConfigurations;
	
	public TestConfiguration(){}
	
	public TestConfiguration(String id, String execute, String buildNo, String fileLocation, String userId, String password,
			String databaseName, String profileName, String emailId, String dbServerName, String dbUserId,
			String dbPassword, String dbName, String d) {
		super();
		this.id = id;
		this.execute = execute;
		this.buildNo = buildNo;
		this.fileLocation = fileLocation;
		this.userId = userId;
		this.password = password;
		this.databaseName = databaseName;
		this.profileName = profileName;
		this.emailId = emailId;
		this.dbServerName = dbServerName;
		this.dbUserId = dbUserId;
		this.dbPassword = dbPassword;
		this.dbName = dbName;
		this.d = d;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getExecute() {
		return execute;
	}
	public void setExecute(String execute) {
		this.execute = execute;
	}
	public String getBuildNo() {
		return buildNo;
	}
	public void setBuildNo(String buildNo) {
		this.buildNo = buildNo;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDbServerName() {
		return dbServerName;
	}
	public void setDbServerName(String dbServerName) {
		this.dbServerName = dbServerName;
	}
	public String getDbUserId() {
		return dbUserId;
	}
	public void setDbUserId(String dbUserId) {
		this.dbUserId = dbUserId;
	}
	public String getDbPassword() {
		return dbPassword;
	}
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getD() {
		return d;
	}
	public void setD(String d) {
		this.d = d;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<TestConfiguration> getTestConfigurations() {
		return testConfigurations;
	}
	public void setTestConfigurations(List<TestConfiguration> testConfigurations) {
		this.testConfigurations = testConfigurations;
	}

	@Override
	public String toString() {
		return "["+testConfigurations+"]";
		/*return "TestConfiguration [id=" + id + ", execute=" + execute + ", buildNo=" + buildNo + ", fileLocation="
				+ fileLocation + ", userId=" + userId + ", password=" + password + ", databaseName=" + databaseName
				+ ", profileName=" + profileName + ", emailId=" + emailId + ", dbServerName=" + dbServerName
				+ ", dbUserId=" + dbUserId + ", dbPassword=" + dbPassword + ", dbName=" + dbName + ", d=" + d
				+ ", configurations=" + configurations + "]";*/
	}
		
}
