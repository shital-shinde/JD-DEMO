package com.yash.service;

import java.io.File;
import java.io.IOException;   
import java.io.InputStream;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Service;
import com.yash.model.Question;
import com.yash.model.TestConfiguration;

@Service
public interface FileUploadService {

	public List<Question> readExcelFile(InputStream inputStream) throws IOException;
	public List<TestConfiguration> readExcelFileUsingPOI(InputStream inputStream, String filepath);
	String saveFileContents(File file, TestConfiguration quest, String filepath) throws InvalidFormatException;
}
