package com.yash.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;   
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import com.yash.model.Question;
import com.yash.model.TestConfiguration;

@Component("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService  {
	int rowno = 0;

	@Override
	public List<Question> readExcelFile(InputStream inputStream){
		Question question = null;
		List<Question> questionList = new ArrayList<Question>();
		try(Workbook workbook = new XSSFWorkbook(inputStream)) {			
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			while (iterator.hasNext()) {
				question = new Question();
				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();
				while (cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();
					currentCell.getColumnIndex();

					if (currentCell.getColumnIndex() == 1 && currentCell.getCellTypeEnum() == CellType.STRING) {
						question.setQuestion(currentCell.getStringCellValue());
						System.out.print(currentCell.getStringCellValue() + "--");
					} else if (currentCell.getColumnIndex() == 2 && currentCell.getCellTypeEnum() == CellType.NUMERIC) {
						question.setOption_1((int) currentCell.getNumericCellValue());
						question.setOption_2((int) currentCell.getNumericCellValue());
						question.setOption_3((int) currentCell.getNumericCellValue());
						question.setOption_4((int) currentCell.getNumericCellValue());
						question.setAnswer((int) currentCell.getNumericCellValue());
						System.out.print(currentCell.getNumericCellValue() + "--");
					}
					questionList.add(question);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return questionList;
	}

	@Override
	public List<TestConfiguration> readExcelFileUsingPOI(InputStream inputStream, String filepath){

		List<TestConfiguration> questionList = new ArrayList<TestConfiguration>();
		try(Workbook workbook = new XSSFWorkbook(inputStream)) {
			Sheet sheet = workbook.getSheetAt(0);
				if(sheet.getPhysicalNumberOfRows() > 0){
					sheet.forEach(row -> {
						TestConfiguration question = new TestConfiguration();						 
						row.forEach(cell -> {
							if (cell.getColumnIndex() == 0) {
								if(cell.getCellTypeEnum() == CellType.STRING)
									question.setId(cell.getStringCellValue());
								else if(cell.getCellTypeEnum() == CellType.NUMERIC)
									question.setId(String.valueOf((int) cell.getNumericCellValue()));
								
							} else if (cell.getColumnIndex() == 1 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setExecute(cell.getStringCellValue());
							} else if (cell.getColumnIndex() == 2 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setBuildNo(cell.getStringCellValue());
							}else if (cell.getColumnIndex() == 3 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setFileLocation(cell.getStringCellValue());	
							}else if (cell.getColumnIndex() == 4 && cell.getCellTypeEnum() == CellType.STRING) {
									question.setUserId(cell.getStringCellValue());	
							}else if (cell.getColumnIndex() == 5 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setPassword(cell.getStringCellValue());		            		
							}else if (cell.getColumnIndex() == 6 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setDatabaseName(cell.getStringCellValue());		            		
							}else if (cell.getColumnIndex() == 7 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setProfileName(cell.getStringCellValue());			            		
							}else if (cell.getColumnIndex() == 8 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setEmailId(cell.getStringCellValue());	
							}else if (cell.getColumnIndex() == 9 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setDbServerName(cell.getStringCellValue());	
							}else if (cell.getColumnIndex() == 10 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setDbUserId(cell.getStringCellValue());
							}else if (cell.getColumnIndex() == 11 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setDbPassword(cell.getStringCellValue());
							}else if (cell.getColumnIndex() == 12 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setDbName(cell.getStringCellValue());
							}else if (cell.getColumnIndex() == 13 && cell.getCellTypeEnum() == CellType.STRING) {
								question.setD(cell.getStringCellValue());
							}
						});

						if(question.getExecute() != null){
							question.setStatus("0");
							questionList.add(question);
						}
					});
				}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return questionList;
	}

	@SuppressWarnings("resource")
	@Override
	public String saveFileContents(File file, TestConfiguration questions,String filepath) throws InvalidFormatException {
		int rowno = 0;
		try{		
			XSSFSheet sheet = new XSSFWorkbook().createSheet();
			for(TestConfiguration quest: questions.getTestConfigurations()){
				if(quest.getStatus() != null && quest.getStatus().equals("1")){
					sheet.createRow(rowno);
					Row row = sheet.createRow(rowno);
					row.createCell(0, CellType.NUMERIC).setCellValue(rowno+1);
					row.createCell(1, CellType.STRING).setCellValue(quest.getExecute());
					row.createCell(2, CellType.STRING).setCellValue(quest.getBuildNo());
					row.createCell(3, CellType.STRING).setCellValue(quest.getFileLocation());
					row.createCell(4, CellType.STRING).setCellValue(quest.getUserId());
					row.createCell(5, CellType.STRING).setCellValue(quest.getPassword());
					row.createCell(6, CellType.STRING).setCellValue(quest.getDatabaseName());
					row.createCell(7, CellType.STRING).setCellValue(quest.getProfileName());
					row.createCell(8, CellType.STRING).setCellValue(quest.getEmailId());
					row.createCell(9, CellType.STRING).setCellValue(quest.getDbServerName());
					row.createCell(10, CellType.STRING).setCellValue(quest.getDbUserId());
					row.createCell(11, CellType.STRING).setCellValue(quest.getDbPassword());
					row.createCell(12, CellType.STRING).setCellValue(quest.getDbName());
					row.createCell(13, CellType.STRING).setCellValue(quest.getD());
					rowno++;				
				}
			}
			sheet.getWorkbook().write(new FileOutputStream(file));
			return "Saved Successfully!!!";
		} catch (IOException e) {
			e.printStackTrace();
			return "Failed to save...Try again.";
		}
	}		
}
