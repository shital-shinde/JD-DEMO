    window.onload = function() {
    	$("#buttonGroup").hide();
    	$("#envTypeDiv").hide(); 
    	
        var ex1 = document.getElementById('file');
        var ex2 = document.getElementById('other');
        ex1.onclick = handler;
        ex2.onclick = otheHandler;
    }
    
    function otheHandler() {
    	$("#tableDiv").hide();
    	$("#buttonGroup").hide(); 
    	$("#envTypeDiv").hide(); 
    	$("#file").prop( "checked", false );
    }
    
    function save() {
    	var rowCount = $('#table tr').length-1;
    	var flag=false;
    	for(var i=0;i<rowCount;i++){
    		var isChecked = document.getElementById('testConfigurations['+i+'].status').value;
     		if(isChecked=="1"){
     			flag=true;
     			break;
     		}else{
     			flag=false;
     		}
    	}

    	if(flag){
    		var formdata = $('#dataform').serialize();
       	 $.ajax({
			  type: "POST",
			  url: "/test/save",
			  data: formdata,
			  dataType: "json",
			  success: function(result) {
				  alert(result.as);

				  if(result.as=="Saved Successfully!!!"){
					  var rowCount = $('#table tr').length-1;
					  for(var i=0;i<rowCount;i++){
						  var isChecked = document.getElementById('testConfigurations['+i+'].status').value;
				     		if(isChecked=="1"){
				     			 setCheckedValue(i);
				     		}
					  } 
					  $('#dataform').trigger("reset");	
				  }else{
					  
				  }
			  }
   	 });   		
    	}else{
    		alert("Please select data.");
    	}

    }
   
    function run() {
    	alert("run");
    }
    
    function setCheckedValue(rowno){
    	var isChecked = document.getElementById('testConfigurations['+rowno+'].status').value;
 		if(isChecked=="0"){
 			document.getElementById('testConfigurations['+rowno+'].status').value = 1;
 		}else{
 			document.getElementById('testConfigurations['+rowno+'].status').value = 0;
 		}
    }
    
    function handler() {
    	$("#other").prop( "checked", false );
    	$("#tableDiv").show();
        $.ajax({
			  type: "POST",
			  url: "/test/readFileContents",
			  dataType: "json",
			  success: function(result) {
				  var row = "";
				  var headerRow = "";
				  if(result[0].execute=="EXECUTE" || result[0].execute=="Execute"|| result[0].execute=="execute"){
					  headerRow = "<tr><th></th>"+
								  "<th>ID</th>"+
								  "<th>EXECUTE</th>"+
								  "<th>BUILD_NO</th>"+
								  "<th>FILE_LOCATION</th>"+
								  "<th>USER_ID</th>"+
								  "<th>PASSWORD</th>"+
								  "<th>DATABASE_NAME</th>"+
								  "<th>PROFILE_NAME</th>"+
								  "<th>EMAIL_ID</th>" +
								  "<th>DB_SERVER_NAME</th>" +
								  "<th>DB_USER_ID</th>" +
								  "<th>DB_PASSWORD</th>" +
								  "<th>DB_Name</th>" +
								  "<th>d</th></tr>";
				  }else{
					  headerRow = "<tr><th></th>"+
					  "<th>"+result[0].id+"</th>"+
					  "<th>"+result[0].execute+"</th>"+
					  "<th>"+result[0].buildNo+"</th>"+
					  "<th>"+result[0].fileLocation+"</th>"+
					  "<th>"+result[0].userId+"</th>"+
					  "<th>"+result[0].password+"</th>"+
					  "<th>"+result[0].databaseName+"</th>"+
					  "<th>"+result[0].profileName+"</th>"+
					  "<th>"+result[0].emailId+"</th>" +
					  "<th>"+result[0].dbServerName+"</th>" +
					  "<th>"+result[0].dbUserId+"</th>" +
					  "<th>"+result[0].dbPassword+"</th>" +
					  "<th>"+result[0].dbName+"</th>" +
					  "<th>"+result[0].d+"</th></tr>";
				  }
				  $("#tableHeader").empty();
				  $("#tableHeader").append(headerRow);
				  $("#tablebody").empty();				
				  
				  for(var i=1,j=0;i<result.length;i++,j++){
					  row += "<tr>"
						  +"<td><input type='checkbox' class='form-control' style='width: 15px;' name='testConfigurations["+j+"].status' id='testConfigurations["+j+"].status' value='0' onchange='setCheckedValue("+j+");'/></td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].id' id='testConfigurations["+j+"].id' value='"+result[i].id+"' />"+result[i].id+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].execute' id='testConfigurations["+j+"].execute' value='"+result[i].execute+"' />"+result[i].execute+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].buildNo' id='testConfigurations["+j+"].buildNo' value='"+result[i].buildNo+"' />"+result[i].buildNo+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].fileLocation' id='testConfigurations["+j+"].fileLocation' value='"+result[i].fileLocation+"' />"+result[i].fileLocation+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].userId' id='testConfigurations["+j+"].userId' value='"+result[i].userId+"' />"+result[i].userId+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].password' id='testConfigurations["+j+"].password' value='"+result[i].password+"' />"+result[i].password+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].databaseName' id='testConfigurations["+j+"].databaseName' value='"+result[i].databaseName+"' />"+result[i].databaseName+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].profileName' id='testConfigurations["+j+"].profileName' value='"+result[i].profileName+"' />"+result[i].profileName+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].emailId' id='testConfigurations["+j+"].emailId' value='"+result[i].emailId+"' />"+result[i].emailId+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].dbServerName' id='testConfigurations["+j+"].dbServerName' value='"+result[i].dbServerName+"' />"+result[i].dbServerName+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].dbUserId' id='testConfigurations["+j+"].dbUserId' value='"+result[i].dbUserId+"' />"+result[i].dbUserId+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].dbPassword' id='testConfigurations["+j+"].dbPassword' value='"+result[i].dbPassword+"' />"+result[i].dbPassword+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].dbName' id='testConfigurations["+j+"].dbName' value='"+result[i].dbName+"' />"+result[i].dbName+"</td>"
						  +"<td><input type='hidden' class='form-control' name='testConfigurations["+j+"].d' id='testConfigurations["+j+"].d' value='"+result[i].d+"' />"+result[i].d+"</td>"
						  +"</tr>";
				  }
				  
				  $("#tablebody").append(row);
				  $("#table").dataTable({"scrollX": true,"scrollY": true,"bDestroy": true});
				  if(result.length > 0){
				  	$("#buttonGroup").show();
				  	$("#envTypeDiv").show();
				  }else{
					$("#buttonGroup").hide();
					$("#envTypeDiv").hide(); 
				  }
			  }
		});
    }